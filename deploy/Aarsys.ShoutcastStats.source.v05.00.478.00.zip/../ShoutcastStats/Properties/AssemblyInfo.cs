using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Aarsys.Modules.ShoutcastStats")]
[assembly: AssemblyDescription("A Shoutcast Statiticviewer for DotNetNuke")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aarsys")]
[assembly: AssemblyProduct("ShoutcastStats")]
[assembly: AssemblyCopyright("(c) Aarsys M.Schlomann 2010")]
[assembly: AssemblyTrademark("")]
[assembly: GuidAttribute("c4f391f9-db6b-4e53-83e5-e9ff8817fe65")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]


// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:
[assembly: AssemblyVersion("5.0.478.0")]
[assembly: AssemblyFileVersion("5.0.478.0")]
